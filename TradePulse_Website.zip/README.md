# TradePulse

**TradePulse** is a modern, responsive, and performance-focused website designed for real-time tracking and predictive analysis of both cryptocurrencies and stock markets.

## 🔥 Features
- Live TradingView-powered charts
- Crypto & stock market analysis
- Asset comparison modules
- AI-powered price prediction (coming soon)
- Mobile-friendly TailwindCSS design

Stay ahead in trading with real-time data and insights.

---
**Live soon via GitHub Pages!**
